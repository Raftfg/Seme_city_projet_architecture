// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package etl_scope_seme_city.create_all_table_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_1
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: create_all_table Purpose: <br>
 * Description:  <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class create_all_table implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(server != null){
				
					this.setProperty("server", server.toString());
				
			}
			
			if(bdd != null){
				
					this.setProperty("bdd", bdd.toString());
				
			}
			
			if(user != null){
				
					this.setProperty("user", user.toString());
				
			}
			
			if(password != null){
				
					this.setProperty("password", password.toString());
				
			}
			
			if(port != null){
				
					this.setProperty("port", port.toString());
				
			}
			
			if(schema != null){
				
					this.setProperty("schema", schema.toString());
				
			}
			
			if(param_supp != null){
				
					this.setProperty("param_supp", param_supp.toString());
				
			}
			
			if(bdd1_server != null){
				
					this.setProperty("bdd1_server", bdd1_server.toString());
				
			}
			
			if(bdd1_port != null){
				
					this.setProperty("bdd1_port", bdd1_port.toString());
				
			}
			
			if(bdd1_schema != null){
				
					this.setProperty("bdd1_schema", bdd1_schema.toString());
				
			}
			
			if(bdd1_bdd != null){
				
					this.setProperty("bdd1_bdd", bdd1_bdd.toString());
				
			}
			
			if(bdd1_param_supp != null){
				
					this.setProperty("bdd1_param_supp", bdd1_param_supp.toString());
				
			}
			
			if(bdd1_password != null){
				
					this.setProperty("bdd1_password", bdd1_password.toString());
				
			}
			
			if(bdd1_user != null){
				
					this.setProperty("bdd1_user", bdd1_user.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String server;
public String getServer(){
	return this.server;
}
public String bdd;
public String getBdd(){
	return this.bdd;
}
public String user;
public String getUser(){
	return this.user;
}
public String password;
public String getPassword(){
	return this.password;
}
public String port;
public String getPort(){
	return this.port;
}
public String schema;
public String getSchema(){
	return this.schema;
}
public String param_supp;
public String getParam_supp(){
	return this.param_supp;
}
public String bdd1_server;
public String getBdd1_server(){
	return this.bdd1_server;
}
public String bdd1_port;
public String getBdd1_port(){
	return this.bdd1_port;
}
public String bdd1_schema;
public String getBdd1_schema(){
	return this.bdd1_schema;
}
public String bdd1_bdd;
public String getBdd1_bdd(){
	return this.bdd1_bdd;
}
public String bdd1_param_supp;
public String getBdd1_param_supp(){
	return this.bdd1_param_supp;
}
public String bdd1_password;
public String getBdd1_password(){
	return this.bdd1_password;
}
public String bdd1_user;
public String getBdd1_user(){
	return this.bdd1_user;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "create_all_table";
	private final String projectName = "ETL_SCOPE_SEME_CITY";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				create_all_table.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(create_all_table.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBRow_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBRow_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBCommit_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBCommit_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBRow_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBCommit_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	





public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";

	
		int tos_count_tDBConnection_1 = 0;
		


	
            String dbProperties_tDBConnection_1 = context.param_supp;
            String url_tDBConnection_1 = "jdbc:postgresql://"+context.server+":"+context.port+"/"+context.bdd;
            
            if(dbProperties_tDBConnection_1 != null && !"".equals(dbProperties_tDBConnection_1.trim())) {
                url_tDBConnection_1 = url_tDBConnection_1 + "?" + dbProperties_tDBConnection_1;
            }
	String dbUser_tDBConnection_1 = context.user;
	
	
		
	final String decryptedPassword_tDBConnection_1 = context.password; 
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_1 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_1 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_1.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_1 = drivers_tDBConnection_1.nextElement();
        if (redShiftDriverNames_tDBConnection_1.contains(d_tDBConnection_1.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_1);
                java.sql.DriverManager.registerDriver(d_tDBConnection_1);
            } catch (java.lang.Exception e_tDBConnection_1) {
globalMap.put("tDBConnection_1_ERROR_MESSAGE",e_tDBConnection_1.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_1 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			conn_tDBConnection_1.setAutoCommit(false);
	}

	globalMap.put("schema_" + "tDBConnection_1",context.schema);

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";

	
		int tos_count_tPostjob_1 = 0;
		

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";

	
		int tos_count_tDBClose_1 = 0;
		

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	



	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
        conn_tDBClose_1.close();
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());




/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";

	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_1", false);
		start_Hash.put("tDBRow_1", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_1";

	
		int tos_count_tDBRow_1 = 0;
		

	java.sql.Connection conn_tDBRow_1 = null;
	String query_tDBRow_1 = "";
	boolean whetherReject_tDBRow_1 = false;
				conn_tDBRow_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_1", conn_tDBRow_1);
        java.sql.Statement stmt_tDBRow_1 = conn_tDBRow_1.createStatement();
        resourceMap.put("stmt_tDBRow_1", stmt_tDBRow_1);


 



/**
 * [tDBRow_1 begin ] stop
 */
	
	/**
	 * [tDBRow_1 main ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

query_tDBRow_1 = "CREATE TABLE IF NOT EXISTS dim_motifs (\n" +
"    id INTEGER  PRIMARY KEY,\n" +
"    nom VARCHAR NOT NULL UNIQUE,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP\n" +
");"
;
whetherReject_tDBRow_1 = false;
globalMap.put("tDBRow_1_QUERY",query_tDBRow_1);
try {
		stmt_tDBRow_1.execute(query_tDBRow_1);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_1 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_1_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_1) {
		
	}
	

 


	tos_count_tDBRow_1++;

/**
 * [tDBRow_1 main ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

 



/**
 * [tDBRow_1 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_1 end ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

	
        stmt_tDBRow_1.close();
        resourceMap.remove("stmt_tDBRow_1");
    resourceMap.put("statementClosed_tDBRow_1", true);
    resourceMap.put("finish_tDBRow_1", true);
 

ok_Hash.put("tDBRow_1", true);
end_Hash.put("tDBRow_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk9", 0, "ok");
				}
				tDBRow_2Process(globalMap);



/**
 * [tDBRow_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_1 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_1";

	

    if (resourceMap.get("statementClosed_tDBRow_1") == null) {
            java.sql.Statement stmtToClose_tDBRow_1 = null;
            if ((stmtToClose_tDBRow_1 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_1")) != null) {
                stmtToClose_tDBRow_1.close();
            }
    }
 



/**
 * [tDBRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_2", false);
		start_Hash.put("tDBRow_2", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_2";

	
		int tos_count_tDBRow_2 = 0;
		

	java.sql.Connection conn_tDBRow_2 = null;
	String query_tDBRow_2 = "";
	boolean whetherReject_tDBRow_2 = false;
				conn_tDBRow_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_2", conn_tDBRow_2);
        java.sql.Statement stmt_tDBRow_2 = conn_tDBRow_2.createStatement();
        resourceMap.put("stmt_tDBRow_2", stmt_tDBRow_2);


 



/**
 * [tDBRow_2 begin ] stop
 */
	
	/**
	 * [tDBRow_2 main ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

query_tDBRow_2 = "CREATE TABLE IF NOT EXISTS dim_professions (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    nom VARCHAR NOT NULL,\n" +
"    created_at TIMESTAMP NOT NULL,\n" +
"    updated_at TIMESTAMP NOT NULL\n" +
");"
;
whetherReject_tDBRow_2 = false;
globalMap.put("tDBRow_2_QUERY",query_tDBRow_2);
try {
		stmt_tDBRow_2.execute(query_tDBRow_2);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_2 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_2_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_2) {
		
	}
	

 


	tos_count_tDBRow_2++;

/**
 * [tDBRow_2 main ] stop
 */
	
	/**
	 * [tDBRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

 



/**
 * [tDBRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

 



/**
 * [tDBRow_2 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_2 end ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

	
        stmt_tDBRow_2.close();
        resourceMap.remove("stmt_tDBRow_2");
    resourceMap.put("statementClosed_tDBRow_2", true);
    resourceMap.put("finish_tDBRow_2", true);
 

ok_Hash.put("tDBRow_2", true);
end_Hash.put("tDBRow_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBRow_3Process(globalMap);



/**
 * [tDBRow_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_2 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_2";

	

    if (resourceMap.get("statementClosed_tDBRow_2") == null) {
            java.sql.Statement stmtToClose_tDBRow_2 = null;
            if ((stmtToClose_tDBRow_2 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_2")) != null) {
                stmtToClose_tDBRow_2.close();
            }
    }
 



/**
 * [tDBRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_2_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_3", false);
		start_Hash.put("tDBRow_3", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_3";

	
		int tos_count_tDBRow_3 = 0;
		

	java.sql.Connection conn_tDBRow_3 = null;
	String query_tDBRow_3 = "";
	boolean whetherReject_tDBRow_3 = false;
				conn_tDBRow_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_3", conn_tDBRow_3);
        java.sql.Statement stmt_tDBRow_3 = conn_tDBRow_3.createStatement();
        resourceMap.put("stmt_tDBRow_3", stmt_tDBRow_3);


 



/**
 * [tDBRow_3 begin ] stop
 */
	
	/**
	 * [tDBRow_3 main ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

query_tDBRow_3 = "CREATE TABLE IF NOT EXISTS dim_pays (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    nom VARCHAR(255) NOT NULL,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP\n" +
");"
;
whetherReject_tDBRow_3 = false;
globalMap.put("tDBRow_3_QUERY",query_tDBRow_3);
try {
		stmt_tDBRow_3.execute(query_tDBRow_3);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_3 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_3_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_3) {
		
	}
	

 


	tos_count_tDBRow_3++;

/**
 * [tDBRow_3 main ] stop
 */
	
	/**
	 * [tDBRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

 



/**
 * [tDBRow_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

 



/**
 * [tDBRow_3 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_3 end ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

	
        stmt_tDBRow_3.close();
        resourceMap.remove("stmt_tDBRow_3");
    resourceMap.put("statementClosed_tDBRow_3", true);
    resourceMap.put("finish_tDBRow_3", true);
 

ok_Hash.put("tDBRow_3", true);
end_Hash.put("tDBRow_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBRow_4Process(globalMap);



/**
 * [tDBRow_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_3 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_3";

	

    if (resourceMap.get("statementClosed_tDBRow_3") == null) {
            java.sql.Statement stmtToClose_tDBRow_3 = null;
            if ((stmtToClose_tDBRow_3 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_3")) != null) {
                stmtToClose_tDBRow_3.close();
            }
    }
 



/**
 * [tDBRow_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_3_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_4", false);
		start_Hash.put("tDBRow_4", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_4";

	
		int tos_count_tDBRow_4 = 0;
		

	java.sql.Connection conn_tDBRow_4 = null;
	String query_tDBRow_4 = "";
	boolean whetherReject_tDBRow_4 = false;
				conn_tDBRow_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_4", conn_tDBRow_4);
        java.sql.Statement stmt_tDBRow_4 = conn_tDBRow_4.createStatement();
        resourceMap.put("stmt_tDBRow_4", stmt_tDBRow_4);


 



/**
 * [tDBRow_4 begin ] stop
 */
	
	/**
	 * [tDBRow_4 main ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

query_tDBRow_4 = "CREATE TABLE IF NOT EXISTS dim_universities (\n" +
"    id SERIAL PRIMARY KEY,\n" +
"    name VARCHAR NOT NULL,\n" +
"    sigle VARCHAR,\n" +
"    pays_id INTEGER,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    CONSTRAINT fk_pays FOREIGN KEY (pays_id) REFERENCES dim_pays(id)\n" +
");"
;
whetherReject_tDBRow_4 = false;
globalMap.put("tDBRow_4_QUERY",query_tDBRow_4);
try {
		stmt_tDBRow_4.execute(query_tDBRow_4);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_4 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_4_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_4) {
		
	}
	

 


	tos_count_tDBRow_4++;

/**
 * [tDBRow_4 main ] stop
 */
	
	/**
	 * [tDBRow_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

 



/**
 * [tDBRow_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

 



/**
 * [tDBRow_4 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_4 end ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

	
        stmt_tDBRow_4.close();
        resourceMap.remove("stmt_tDBRow_4");
    resourceMap.put("statementClosed_tDBRow_4", true);
    resourceMap.put("finish_tDBRow_4", true);
 

ok_Hash.put("tDBRow_4", true);
end_Hash.put("tDBRow_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tDBRow_5Process(globalMap);



/**
 * [tDBRow_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_4 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_4";

	

    if (resourceMap.get("statementClosed_tDBRow_4") == null) {
            java.sql.Statement stmtToClose_tDBRow_4 = null;
            if ((stmtToClose_tDBRow_4 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_4")) != null) {
                stmtToClose_tDBRow_4.close();
            }
    }
 



/**
 * [tDBRow_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_4_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_5", false);
		start_Hash.put("tDBRow_5", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_5";

	
		int tos_count_tDBRow_5 = 0;
		

	java.sql.Connection conn_tDBRow_5 = null;
	String query_tDBRow_5 = "";
	boolean whetherReject_tDBRow_5 = false;
				conn_tDBRow_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_5", conn_tDBRow_5);
        java.sql.Statement stmt_tDBRow_5 = conn_tDBRow_5.createStatement();
        resourceMap.put("stmt_tDBRow_5", stmt_tDBRow_5);


 



/**
 * [tDBRow_5 begin ] stop
 */
	
	/**
	 * [tDBRow_5 main ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

query_tDBRow_5 = "CREATE TABLE IF NOT EXISTS dim_ville (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    nom VARCHAR NOT NULL UNIQUE,\n" +
"    pays_id INTEGER,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    CONSTRAINT fk_pays FOREIGN KEY (pays_id) REFERENCES dim_pays(id),\n" +
"    CONSTRAINT unique_nom_pays UNIQUE (nom, pays_id)\n" +
");"
;
whetherReject_tDBRow_5 = false;
globalMap.put("tDBRow_5_QUERY",query_tDBRow_5);
try {
		stmt_tDBRow_5.execute(query_tDBRow_5);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_5 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_5_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_5) {
		
	}
	

 


	tos_count_tDBRow_5++;

/**
 * [tDBRow_5 main ] stop
 */
	
	/**
	 * [tDBRow_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

 



/**
 * [tDBRow_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

 



/**
 * [tDBRow_5 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_5 end ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

	
        stmt_tDBRow_5.close();
        resourceMap.remove("stmt_tDBRow_5");
    resourceMap.put("statementClosed_tDBRow_5", true);
    resourceMap.put("finish_tDBRow_5", true);
 

ok_Hash.put("tDBRow_5", true);
end_Hash.put("tDBRow_5", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tDBRow_8Process(globalMap);



/**
 * [tDBRow_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_5 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_5";

	

    if (resourceMap.get("statementClosed_tDBRow_5") == null) {
            java.sql.Statement stmtToClose_tDBRow_5 = null;
            if ((stmtToClose_tDBRow_5 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_5")) != null) {
                stmtToClose_tDBRow_5.close();
            }
    }
 



/**
 * [tDBRow_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_5_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_8", false);
		start_Hash.put("tDBRow_8", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_8";

	
		int tos_count_tDBRow_8 = 0;
		

	java.sql.Connection conn_tDBRow_8 = null;
	String query_tDBRow_8 = "";
	boolean whetherReject_tDBRow_8 = false;
				conn_tDBRow_8 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_8", conn_tDBRow_8);
        java.sql.Statement stmt_tDBRow_8 = conn_tDBRow_8.createStatement();
        resourceMap.put("stmt_tDBRow_8", stmt_tDBRow_8);


 



/**
 * [tDBRow_8 begin ] stop
 */
	
	/**
	 * [tDBRow_8 main ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

query_tDBRow_8 = "CREATE TABLE IF NOT EXISTS dim_specialities (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    name VARCHAR NOT NULL,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP\n" +
");"
;
whetherReject_tDBRow_8 = false;
globalMap.put("tDBRow_8_QUERY",query_tDBRow_8);
try {
		stmt_tDBRow_8.execute(query_tDBRow_8);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_8 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_8_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_8) {
		
	}
	

 


	tos_count_tDBRow_8++;

/**
 * [tDBRow_8 main ] stop
 */
	
	/**
	 * [tDBRow_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

 



/**
 * [tDBRow_8 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

 



/**
 * [tDBRow_8 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_8 end ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

	
        stmt_tDBRow_8.close();
        resourceMap.remove("stmt_tDBRow_8");
    resourceMap.put("statementClosed_tDBRow_8", true);
    resourceMap.put("finish_tDBRow_8", true);
 

ok_Hash.put("tDBRow_8", true);
end_Hash.put("tDBRow_8", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tDBRow_7Process(globalMap);



/**
 * [tDBRow_8 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_8 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_8";

	

    if (resourceMap.get("statementClosed_tDBRow_8") == null) {
            java.sql.Statement stmtToClose_tDBRow_8 = null;
            if ((stmtToClose_tDBRow_8 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_8")) != null) {
                stmtToClose_tDBRow_8.close();
            }
    }
 



/**
 * [tDBRow_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_8_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_7", false);
		start_Hash.put("tDBRow_7", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_7";

	
		int tos_count_tDBRow_7 = 0;
		

	java.sql.Connection conn_tDBRow_7 = null;
	String query_tDBRow_7 = "";
	boolean whetherReject_tDBRow_7 = false;
				conn_tDBRow_7 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_7", conn_tDBRow_7);
        java.sql.Statement stmt_tDBRow_7 = conn_tDBRow_7.createStatement();
        resourceMap.put("stmt_tDBRow_7", stmt_tDBRow_7);


 



/**
 * [tDBRow_7 begin ] stop
 */
	
	/**
	 * [tDBRow_7 main ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

query_tDBRow_7 = "CREATE TABLE IF NOT EXISTS dim_roles (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    label VARCHAR NOT NULL,\n" +
"    permissions TEXT,\n" +
"    tag VARCHAR,\n" +
"    ancien_role_id INTEGER,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP\n" +
");"
;
whetherReject_tDBRow_7 = false;
globalMap.put("tDBRow_7_QUERY",query_tDBRow_7);
try {
		stmt_tDBRow_7.execute(query_tDBRow_7);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_7 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_7_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_7) {
		
	}
	

 


	tos_count_tDBRow_7++;

/**
 * [tDBRow_7 main ] stop
 */
	
	/**
	 * [tDBRow_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

 



/**
 * [tDBRow_7 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

 



/**
 * [tDBRow_7 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_7 end ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

	
        stmt_tDBRow_7.close();
        resourceMap.remove("stmt_tDBRow_7");
    resourceMap.put("statementClosed_tDBRow_7", true);
    resourceMap.put("finish_tDBRow_7", true);
 

ok_Hash.put("tDBRow_7", true);
end_Hash.put("tDBRow_7", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk7", 0, "ok");
				}
				tDBRow_6Process(globalMap);



/**
 * [tDBRow_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_7 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_7";

	

    if (resourceMap.get("statementClosed_tDBRow_7") == null) {
            java.sql.Statement stmtToClose_tDBRow_7 = null;
            if ((stmtToClose_tDBRow_7 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_7")) != null) {
                stmtToClose_tDBRow_7.close();
            }
    }
 



/**
 * [tDBRow_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_7_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_6", false);
		start_Hash.put("tDBRow_6", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_6";

	
		int tos_count_tDBRow_6 = 0;
		

	java.sql.Connection conn_tDBRow_6 = null;
	String query_tDBRow_6 = "";
	boolean whetherReject_tDBRow_6 = false;
				conn_tDBRow_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_6", conn_tDBRow_6);
        java.sql.Statement stmt_tDBRow_6 = conn_tDBRow_6.createStatement();
        resourceMap.put("stmt_tDBRow_6", stmt_tDBRow_6);


 



/**
 * [tDBRow_6 begin ] stop
 */
	
	/**
	 * [tDBRow_6 main ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

query_tDBRow_6 = "CREATE TABLE IF NOT EXISTS dim_espace (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    nom VARCHAR NOT NULL UNIQUE,\n" +
"    description TEXT,\n" +
"    capacity INTEGER,\n" +
"    tag VARCHAR,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP\n" +
");"
;
whetherReject_tDBRow_6 = false;
globalMap.put("tDBRow_6_QUERY",query_tDBRow_6);
try {
		stmt_tDBRow_6.execute(query_tDBRow_6);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_6 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_6_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_6) {
		
	}
	

 


	tos_count_tDBRow_6++;

/**
 * [tDBRow_6 main ] stop
 */
	
	/**
	 * [tDBRow_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

 



/**
 * [tDBRow_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

 



/**
 * [tDBRow_6 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_6 end ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

	
        stmt_tDBRow_6.close();
        resourceMap.remove("stmt_tDBRow_6");
    resourceMap.put("statementClosed_tDBRow_6", true);
    resourceMap.put("finish_tDBRow_6", true);
 

ok_Hash.put("tDBRow_6", true);
end_Hash.put("tDBRow_6", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk10", 0, "ok");
				}
				tDBRow_9Process(globalMap);



/**
 * [tDBRow_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_6 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_6";

	

    if (resourceMap.get("statementClosed_tDBRow_6") == null) {
            java.sql.Statement stmtToClose_tDBRow_6 = null;
            if ((stmtToClose_tDBRow_6 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_6")) != null) {
                stmtToClose_tDBRow_6.close();
            }
    }
 



/**
 * [tDBRow_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_6_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_9", false);
		start_Hash.put("tDBRow_9", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_9";

	
		int tos_count_tDBRow_9 = 0;
		

	java.sql.Connection conn_tDBRow_9 = null;
	String query_tDBRow_9 = "";
	boolean whetherReject_tDBRow_9 = false;
				conn_tDBRow_9 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_9", conn_tDBRow_9);
        java.sql.Statement stmt_tDBRow_9 = conn_tDBRow_9.createStatement();
        resourceMap.put("stmt_tDBRow_9", stmt_tDBRow_9);


 



/**
 * [tDBRow_9 begin ] stop
 */
	
	/**
	 * [tDBRow_9 main ] start
	 */

	

	
	
	currentComponent="tDBRow_9";

	

query_tDBRow_9 = "CREATE TABLE IF NOT EXISTS dim_time (\n" +
"  id SERIAL PRIMARY KEY,\n" +
"    full_date DATE  UNIQUE,\n" +
"    date_id INTEGER NOT NULL UNIQUE,\n" +
"    day INTEGER NOT NULL,\n" +
"    month INTEGER NOT NULL,\n" +
"    year INTEGER NOT NULL,\n" +
"    quarter INTEGER NOT NULL,\n" +
"    day_of_week INTEGER NOT NULL,\n" +
"    week_number INTEGER NOT NULL,\n" +
"    day_name VARCHAR NOT NULL,\n" +
"    month_name VARCHAR NOT NULL,\n" +
"    is_weekend BOOLEAN NOT NULL,\n" +
"    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n" +
");"
;
whetherReject_tDBRow_9 = false;
globalMap.put("tDBRow_9_QUERY",query_tDBRow_9);
try {
		stmt_tDBRow_9.execute(query_tDBRow_9);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_9 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_9_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_9) {
		
	}
	

 


	tos_count_tDBRow_9++;

/**
 * [tDBRow_9 main ] stop
 */
	
	/**
	 * [tDBRow_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_9";

	

 



/**
 * [tDBRow_9 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_9";

	

 



/**
 * [tDBRow_9 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_9 end ] start
	 */

	

	
	
	currentComponent="tDBRow_9";

	

	
        stmt_tDBRow_9.close();
        resourceMap.remove("stmt_tDBRow_9");
    resourceMap.put("statementClosed_tDBRow_9", true);
    resourceMap.put("finish_tDBRow_9", true);
 

ok_Hash.put("tDBRow_9", true);
end_Hash.put("tDBRow_9", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk12", 0, "ok");
				}
				tDBRow_10Process(globalMap);



/**
 * [tDBRow_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_9 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_9";

	

    if (resourceMap.get("statementClosed_tDBRow_9") == null) {
            java.sql.Statement stmtToClose_tDBRow_9 = null;
            if ((stmtToClose_tDBRow_9 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_9")) != null) {
                stmtToClose_tDBRow_9.close();
            }
    }
 



/**
 * [tDBRow_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_9_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_10", false);
		start_Hash.put("tDBRow_10", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_10";

	
		int tos_count_tDBRow_10 = 0;
		

	java.sql.Connection conn_tDBRow_10 = null;
	String query_tDBRow_10 = "";
	boolean whetherReject_tDBRow_10 = false;
				conn_tDBRow_10 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_10", conn_tDBRow_10);
        java.sql.Statement stmt_tDBRow_10 = conn_tDBRow_10.createStatement();
        resourceMap.put("stmt_tDBRow_10", stmt_tDBRow_10);


 



/**
 * [tDBRow_10 begin ] stop
 */
	
	/**
	 * [tDBRow_10 main ] start
	 */

	

	
	
	currentComponent="tDBRow_10";

	

query_tDBRow_10 = "CREATE TABLE IF NOT EXISTS fact_fluxscope_users (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    nom VARCHAR NOT NULL,\n" +
"    prenoms VARCHAR,\n" +
"    telephone VARCHAR,\n" +
"    status VARCHAR,\n" +
"    email VARCHAR NOT NULL,\n" +
"    sexe VARCHAR,\n" +
"    profession_id INTEGER,\n" +
"    is_handicap VARCHAR,\n" +
"    pin VARCHAR,\n" +
"    ancien_user_id INTEGER,\n" +
"    ville_id INTEGER,\n" +
"    universities_id INTEGER,\n" +
"    specialities_id INTEGER,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    CONSTRAINT fk_profession FOREIGN KEY (profession_id) REFERENCES " +context.schema+ ".dim_professions(id),\n" +
"    CONSTRAINT fk_ville FOREIGN KEY (ville_id) REFERENCES " + context.schema + ".dim_ville(id),\n" +
"    CONSTRAINT fk_universities FOREIGN KEY (universities_id) REFERENCES " + context.schema + ".dim_universities(id),\n" +
"    CONSTRAINT fk_specialities FOREIGN KEY (specialities_id) REFERENCES " + context.schema + ".dim_specialities(id)\n" +
");"
;
whetherReject_tDBRow_10 = false;
globalMap.put("tDBRow_10_QUERY",query_tDBRow_10);
try {
		stmt_tDBRow_10.execute(query_tDBRow_10);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_10 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_10_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_10) {
		
	}
	

 


	tos_count_tDBRow_10++;

/**
 * [tDBRow_10 main ] stop
 */
	
	/**
	 * [tDBRow_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_10";

	

 



/**
 * [tDBRow_10 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_10";

	

 



/**
 * [tDBRow_10 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_10 end ] start
	 */

	

	
	
	currentComponent="tDBRow_10";

	

	
        stmt_tDBRow_10.close();
        resourceMap.remove("stmt_tDBRow_10");
    resourceMap.put("statementClosed_tDBRow_10", true);
    resourceMap.put("finish_tDBRow_10", true);
 

ok_Hash.put("tDBRow_10", true);
end_Hash.put("tDBRow_10", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk11", 0, "ok");
				}
				tDBRow_11Process(globalMap);



/**
 * [tDBRow_10 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_10 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_10";

	

    if (resourceMap.get("statementClosed_tDBRow_10") == null) {
            java.sql.Statement stmtToClose_tDBRow_10 = null;
            if ((stmtToClose_tDBRow_10 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_10")) != null) {
                stmtToClose_tDBRow_10.close();
            }
    }
 



/**
 * [tDBRow_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_10_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_11", false);
		start_Hash.put("tDBRow_11", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_11";

	
		int tos_count_tDBRow_11 = 0;
		

	java.sql.Connection conn_tDBRow_11 = null;
	String query_tDBRow_11 = "";
	boolean whetherReject_tDBRow_11 = false;
				conn_tDBRow_11 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_11", conn_tDBRow_11);
        java.sql.Statement stmt_tDBRow_11 = conn_tDBRow_11.createStatement();
        resourceMap.put("stmt_tDBRow_11", stmt_tDBRow_11);


 



/**
 * [tDBRow_11 begin ] stop
 */
	
	/**
	 * [tDBRow_11 main ] start
	 */

	

	
	
	currentComponent="tDBRow_11";

	

query_tDBRow_11 = "CREATE TABLE IF NOT EXISTS " + context.schema + ".fact_fluxscope_presence (\n" +
"    id SERIAL PRIMARY KEY,\n" +
"    arrival_date TIMESTAMP NOT NULL,\n" +
"    departure_date TIMESTAMP,\n" +
"    motif_id INTEGER,\n" +
"    espace_id INTEGER,\n" +
"    user_id INTEGER,\n" +
"    date_id INTEGER,\n" +
"    ancien_presence_id INTEGER,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    CONSTRAINT fk_motif FOREIGN KEY (motif_id) REFERENCES " + context.schema + ".dim_motifs(id),\n" +
"    CONSTRAINT fk_espace FOREIGN KEY (espace_id) REFERENCES " + context.schema + ".dim_espace(id),\n" +
"    CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES " + context.schema + ".fact_fluxscope_users(id),\n" +
"    CONSTRAINT fk_date FOREIGN KEY (date_id) REFERENCES " + context.schema + ".dim_time(id)\n" +
");"
;
whetherReject_tDBRow_11 = false;
globalMap.put("tDBRow_11_QUERY",query_tDBRow_11);
try {
		stmt_tDBRow_11.execute(query_tDBRow_11);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_11 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_11_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_11) {
		
	}
	

 


	tos_count_tDBRow_11++;

/**
 * [tDBRow_11 main ] stop
 */
	
	/**
	 * [tDBRow_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_11";

	

 



/**
 * [tDBRow_11 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_11";

	

 



/**
 * [tDBRow_11 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_11 end ] start
	 */

	

	
	
	currentComponent="tDBRow_11";

	

	
        stmt_tDBRow_11.close();
        resourceMap.remove("stmt_tDBRow_11");
    resourceMap.put("statementClosed_tDBRow_11", true);
    resourceMap.put("finish_tDBRow_11", true);
 

ok_Hash.put("tDBRow_11", true);
end_Hash.put("tDBRow_11", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk13", 0, "ok");
				}
				tDBRow_12Process(globalMap);



/**
 * [tDBRow_11 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_11 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_11";

	

    if (resourceMap.get("statementClosed_tDBRow_11") == null) {
            java.sql.Statement stmtToClose_tDBRow_11 = null;
            if ((stmtToClose_tDBRow_11 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_11")) != null) {
                stmtToClose_tDBRow_11.close();
            }
    }
 



/**
 * [tDBRow_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_11_SUBPROCESS_STATE", 1);
	}
	

public void tDBRow_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBRow_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBRow_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBRow_12", false);
		start_Hash.put("tDBRow_12", System.currentTimeMillis());
		
	
	currentComponent="tDBRow_12";

	
		int tos_count_tDBRow_12 = 0;
		

	java.sql.Connection conn_tDBRow_12 = null;
	String query_tDBRow_12 = "";
	boolean whetherReject_tDBRow_12 = false;
				conn_tDBRow_12 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
			
        resourceMap.put("conn_tDBRow_12", conn_tDBRow_12);
        java.sql.Statement stmt_tDBRow_12 = conn_tDBRow_12.createStatement();
        resourceMap.put("stmt_tDBRow_12", stmt_tDBRow_12);


 



/**
 * [tDBRow_12 begin ] stop
 */
	
	/**
	 * [tDBRow_12 main ] start
	 */

	

	
	
	currentComponent="tDBRow_12";

	

query_tDBRow_12 = "CREATE TABLE IF NOT EXISTS " +context.schema+ ".fact_fluxscope_accounts (\n" +
"    id INTEGER PRIMARY KEY,\n" +
"    email VARCHAR NOT NULL UNIQUE,\n" +
"    password_hash TEXT NOT NULL,\n" +
"    is_active BOOLEAN,\n" +
"    role_id INTEGER,\n" +
"    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
"    CONSTRAINT fk_role FOREIGN KEY (role_id) REFERENCES " + context.schema + ".dim_roles(id)\n" +
");"
;
whetherReject_tDBRow_12 = false;
globalMap.put("tDBRow_12_QUERY",query_tDBRow_12);
try {
		stmt_tDBRow_12.execute(query_tDBRow_12);
		
	} catch (java.lang.Exception e) {
		whetherReject_tDBRow_12 = true;
		
				System.err.print(e.getMessage());
				globalMap.put("tDBRow_12_ERROR_MESSAGE", e.getMessage());
				
	}
	
	if(!whetherReject_tDBRow_12) {
		
	}
	

 


	tos_count_tDBRow_12++;

/**
 * [tDBRow_12 main ] stop
 */
	
	/**
	 * [tDBRow_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBRow_12";

	

 



/**
 * [tDBRow_12 process_data_begin ] stop
 */
	
	/**
	 * [tDBRow_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBRow_12";

	

 



/**
 * [tDBRow_12 process_data_end ] stop
 */
	
	/**
	 * [tDBRow_12 end ] start
	 */

	

	
	
	currentComponent="tDBRow_12";

	

	
        stmt_tDBRow_12.close();
        resourceMap.remove("stmt_tDBRow_12");
    resourceMap.put("statementClosed_tDBRow_12", true);
    resourceMap.put("finish_tDBRow_12", true);
 

ok_Hash.put("tDBRow_12", true);
end_Hash.put("tDBRow_12", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk15", 0, "ok");
				}
				tDBCommit_1Process(globalMap);



/**
 * [tDBRow_12 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBRow_12 finally ] start
	 */

	

	
	
	currentComponent="tDBRow_12";

	

    if (resourceMap.get("statementClosed_tDBRow_12") == null) {
            java.sql.Statement stmtToClose_tDBRow_12 = null;
            if ((stmtToClose_tDBRow_12 = (java.sql.Statement) resourceMap.remove("stmt_tDBRow_12")) != null) {
                stmtToClose_tDBRow_12.close();
            }
    }
 



/**
 * [tDBRow_12 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBRow_12_SUBPROCESS_STATE", 1);
	}
	

public void tDBCommit_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBCommit_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBCommit_1", false);
		start_Hash.put("tDBCommit_1", System.currentTimeMillis());
		
	
	currentComponent="tDBCommit_1";

	
		int tos_count_tDBCommit_1 = 0;
		

 



/**
 * [tDBCommit_1 begin ] stop
 */
	
	/**
	 * [tDBCommit_1 main ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

	java.sql.Connection conn_tDBCommit_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBCommit_1 != null && !conn_tDBCommit_1.isClosed())
	{
	
			
			conn_tDBCommit_1.commit();
			
	
	}

 


	tos_count_tDBCommit_1++;

/**
 * [tDBCommit_1 main ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 process_data_end ] stop
 */
	
	/**
	 * [tDBCommit_1 end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 

ok_Hash.put("tDBCommit_1", true);
end_Hash.put("tDBCommit_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk14", 0, "ok");
				}
				tJava_1Process(globalMap);



/**
 * [tDBCommit_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBCommit_1 finally ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		


System.out.println("FluxScope : Création de toutes les tables de la bdd staging terminée avec succès.");

 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_begin ] stop
 */
	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final create_all_table create_all_tableClass = new create_all_table();

        int exitCode = create_all_tableClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = create_all_table.class.getClassLoader().getResourceAsStream("etl_scope_seme_city/create_all_table_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = create_all_table.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("server", "id_String");
                        if(context.getStringValue("server") == null) {
                            context.server = null;
                        } else {
                            context.server=(String) context.getProperty("server");
                        }
                        context.setContextType("bdd", "id_String");
                        if(context.getStringValue("bdd") == null) {
                            context.bdd = null;
                        } else {
                            context.bdd=(String) context.getProperty("bdd");
                        }
                        context.setContextType("user", "id_String");
                        if(context.getStringValue("user") == null) {
                            context.user = null;
                        } else {
                            context.user=(String) context.getProperty("user");
                        }
                        context.setContextType("password", "id_String");
                        if(context.getStringValue("password") == null) {
                            context.password = null;
                        } else {
                            context.password=(String) context.getProperty("password");
                        }
                        context.setContextType("port", "id_String");
                        if(context.getStringValue("port") == null) {
                            context.port = null;
                        } else {
                            context.port=(String) context.getProperty("port");
                        }
                        context.setContextType("schema", "id_String");
                        if(context.getStringValue("schema") == null) {
                            context.schema = null;
                        } else {
                            context.schema=(String) context.getProperty("schema");
                        }
                        context.setContextType("param_supp", "id_String");
                        if(context.getStringValue("param_supp") == null) {
                            context.param_supp = null;
                        } else {
                            context.param_supp=(String) context.getProperty("param_supp");
                        }
                        context.setContextType("bdd1_server", "id_String");
                        if(context.getStringValue("bdd1_server") == null) {
                            context.bdd1_server = null;
                        } else {
                            context.bdd1_server=(String) context.getProperty("bdd1_server");
                        }
                        context.setContextType("bdd1_port", "id_String");
                        if(context.getStringValue("bdd1_port") == null) {
                            context.bdd1_port = null;
                        } else {
                            context.bdd1_port=(String) context.getProperty("bdd1_port");
                        }
                        context.setContextType("bdd1_schema", "id_String");
                        if(context.getStringValue("bdd1_schema") == null) {
                            context.bdd1_schema = null;
                        } else {
                            context.bdd1_schema=(String) context.getProperty("bdd1_schema");
                        }
                        context.setContextType("bdd1_bdd", "id_String");
                        if(context.getStringValue("bdd1_bdd") == null) {
                            context.bdd1_bdd = null;
                        } else {
                            context.bdd1_bdd=(String) context.getProperty("bdd1_bdd");
                        }
                        context.setContextType("bdd1_param_supp", "id_String");
                        if(context.getStringValue("bdd1_param_supp") == null) {
                            context.bdd1_param_supp = null;
                        } else {
                            context.bdd1_param_supp=(String) context.getProperty("bdd1_param_supp");
                        }
                        context.setContextType("bdd1_password", "id_String");
                        if(context.getStringValue("bdd1_password") == null) {
                            context.bdd1_password = null;
                        } else {
                            context.bdd1_password=(String) context.getProperty("bdd1_password");
                        }
                        context.setContextType("bdd1_user", "id_String");
                        if(context.getStringValue("bdd1_user") == null) {
                            context.bdd1_user = null;
                        } else {
                            context.bdd1_user=(String) context.getProperty("bdd1_user");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("server")) {
                context.server = (String) parentContextMap.get("server");
            }if (parentContextMap.containsKey("bdd")) {
                context.bdd = (String) parentContextMap.get("bdd");
            }if (parentContextMap.containsKey("user")) {
                context.user = (String) parentContextMap.get("user");
            }if (parentContextMap.containsKey("password")) {
                context.password = (String) parentContextMap.get("password");
            }if (parentContextMap.containsKey("port")) {
                context.port = (String) parentContextMap.get("port");
            }if (parentContextMap.containsKey("schema")) {
                context.schema = (String) parentContextMap.get("schema");
            }if (parentContextMap.containsKey("param_supp")) {
                context.param_supp = (String) parentContextMap.get("param_supp");
            }if (parentContextMap.containsKey("bdd1_server")) {
                context.bdd1_server = (String) parentContextMap.get("bdd1_server");
            }if (parentContextMap.containsKey("bdd1_port")) {
                context.bdd1_port = (String) parentContextMap.get("bdd1_port");
            }if (parentContextMap.containsKey("bdd1_schema")) {
                context.bdd1_schema = (String) parentContextMap.get("bdd1_schema");
            }if (parentContextMap.containsKey("bdd1_bdd")) {
                context.bdd1_bdd = (String) parentContextMap.get("bdd1_bdd");
            }if (parentContextMap.containsKey("bdd1_param_supp")) {
                context.bdd1_param_supp = (String) parentContextMap.get("bdd1_param_supp");
            }if (parentContextMap.containsKey("bdd1_password")) {
                context.bdd1_password = (String) parentContextMap.get("bdd1_password");
            }if (parentContextMap.containsKey("bdd1_user")) {
                context.bdd1_user = (String) parentContextMap.get("bdd1_user");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}




this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBRow_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBRow_1) {
globalMap.put("tDBRow_1_SUBPROCESS_STATE", -1);

e_tDBRow_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : create_all_table");
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     116379 characters generated by Talend Open Studio for Data Integration 
 *     on the 21 juillet 2025, 11:52:22 WAT
 ************************************************************************************************/